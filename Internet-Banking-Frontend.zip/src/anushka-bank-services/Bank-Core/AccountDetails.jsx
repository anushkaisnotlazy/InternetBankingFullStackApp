import React, { useEffect, useState } from 'react';
import axiosInstance from '../utils/axiosInstance';
import 'bootstrap/dist/css/bootstrap.min.css';

const AccountDetails = () => {
    const [accountDetails, setAccountDetails] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [inputAccountNumber, setInputAccountNumber] = useState('');
    const [submittedAccountNumber, setSubmittedAccountNumber] = useState('');

    useEffect(() => {
        const fetchAccountDetails = async () => {
            try {
                const response = await axiosInstance.get(`http://localhost:1234/accounts/${submittedAccountNumber}`);
                setAccountDetails(response.data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        if (submittedAccountNumber) {
            fetchAccountDetails();
        }
    }, [submittedAccountNumber]);

    const handleSubmit = (e) => {
        e.preventDefault();
        setSubmittedAccountNumber(inputAccountNumber);
    };

    return (
        <div className="container mt-5">
            <div className="card text-white bg-dark mb-3">
                <div className="card-header bg-primary">Account Details</div>
                <div className="card-body">
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="accountNumber">Account Number</label>
                            <input
                                type="text"
                                className="form-control"
                                id="accountNumber"
                                value={inputAccountNumber}
                                onChange={(e) => setInputAccountNumber(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-primary mt-3">Submit</button>
                    </form>
                    {loading && <div>Loading...</div>}
                    {error && <div>Error: {error}</div>}
                    {accountDetails && (
                        <div>
                            <h2>Account Details</h2>
                            <p><strong>Account Number:</strong> {accountDetails.accountNumber}</p>
                            <p><strong>Account Holder Name:</strong> {accountDetails.accountHolderName}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AccountDetails;
