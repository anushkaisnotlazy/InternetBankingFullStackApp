import React, { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const CurrentBalance = () => {
    const [balance, setBalance] = useState(null);
    const [accountDetails, setAccountDetails] = useState({});
    const [accountNumber, setAccountNumber] = useState('');

    const fetchAccountDetails = async () => {
        try {
            const response = await axios.get(`http://localhost:1234/accounts/balance/${accountNumber}`,{
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            // setAccountDetails(response.data);
            setBalance(response.data);
            console.log(response.data);
        } catch (error) {
            console.error('Error fetching account details:', error);
        }
    };

    return (
        <div className="container mt-5">
            <div className="card">
                <div className="card-header">
                    <h3>Current Balance</h3>
                </div>
                <div className="card-body">
                    <div className="mb-3">
                        <label htmlFor="accountNumber" className="form-label">Account Number</label>
                        <input
                            type="text"
                            className="form-control"
                            id="accountNumber"
                            value={accountNumber}
                            onChange={(e) => setAccountNumber(e.target.value)}
                        />
                    </div>
                    <button className="btn btn-primary" onClick={fetchAccountDetails}>Get Balance</button>
                    {balance && (
                        <div className="card mt-3" style={{ backgroundColor: 'purple', color: 'white' }}>
                            <div className="card-body">
                                <p className="card-text">Current Balance: ₹ {balance}</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CurrentBalance;