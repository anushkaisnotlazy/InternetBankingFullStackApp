import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Container, Row, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const TransactionHistory = () => {
    const [transactions, setTransactions] = useState([]);

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const response = await axios.get('http://localhost:8082/transactions');
                setTransactions(response.data);
            } catch (error) {
                console.error('Error fetching transaction history:', error);
            }
        };

        fetchTransactions();
    }, []);

    return (
        <Container>
            <h2 className="my-4">Transaction History</h2>
            <Row>
                {transactions.map((transaction) => (
                    <Col md={4} key={transaction.id} className="mb-4">
                        <Card>
                            <Card.Body>
                                <Card.Title>{transaction.type}</Card.Title>
                                <Card.Text>
                                    <strong>Account Number:</strong> {transaction.accountNumber}
                                </Card.Text>
                                <Card.Text>
                                    <strong>Amount:</strong> ${transaction.amount}
                                </Card.Text>
                                <Card.Text>
                                    <strong>Date:</strong> {new Date(transaction.timestamp).toLocaleString()}
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
};

export default TransactionHistory;