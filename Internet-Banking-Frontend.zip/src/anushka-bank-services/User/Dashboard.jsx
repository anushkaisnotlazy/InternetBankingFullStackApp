import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Navbar, Nav, Button, Card } from 'react-bootstrap';
import { FaPhone, FaEnvelope, FaMapMarkerAlt } from 'react-icons/fa';

const Dashboard = () => {
    return (
        <div>
            <Container className="mt-5">
                <Row className="text-center">
                    <Col>
                        <h1 align="center" sty>Welcome to Bank of Anushka</h1>
                        <h3>Your trusted partner in financial services</h3>
                        <Button variant="primary" href="#about">Learn More</Button>
                    </Col>
                </Row>

                <Row id="about" className="mt-5">
                    <Col>
                        <h2>About Us</h2>
                        <Card>
                            <Card.Body>
                                <Card.Text>
                                    At Anushka Bank, we are committed to providing the best financial services to our customers. Our team of experienced professionals is dedicated to helping you achieve your financial goals.
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>

                <Row id="contact" className="mt-5">
                    <Col>
                        <h2>Contact Us</h2>
                        <Card>
                            <Card.Body>
                                <Card.Text>
                                    <FaPhone /> +91 234 567 890<br />
                                    <FaEnvelope /> contact@anushkabank.com<br />
                                    <FaMapMarkerAlt /> 123 Main Street, Very famous City, Bharat
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Dashboard;