package com.anushka.bankcore;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.anushka.bankcore.dao.AccountRepository;
import com.anushka.bankcore.model.Account;
import com.anushka.bankcore.service.AccountServiceImpl;

@SpringBootTest
class BankcoreApplicationTests {


    @Mock
    private AccountRepository accountRepository;

    @InjectMocks
    private AccountServiceImpl accountService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void testCreateAccount() {
        Account account = new Account();
        account.setAccountNumber("12345");
        account.setBalance(1000.0);

        when(accountRepository.save(account)).thenReturn(account);

        Account createdAccount = accountService.createAccount(account);

        assertNotNull(createdAccount);
        assertEquals("12345", createdAccount.getAccountNumber());
        assertEquals(1000.0, createdAccount.getBalance());
        verify(accountRepository, times(1)).save(account);
    }

}
