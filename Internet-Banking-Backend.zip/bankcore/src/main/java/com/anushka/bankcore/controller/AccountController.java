package com.anushka.bankcore.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anushka.bankcore.model.Account;
import com.anushka.bankcore.service.AccountService;

/**
 * REST controller for managing accounts.
 */
@RestController
@RequestMapping("/accounts")
//@CrossOrigin("*")
public class AccountController {

	@Autowired
	private AccountService accountService;	

	/**
	 * Registers a new account.
	 * 
	 * @param account the account to be created
	 * @return the created account
	 * 
	 * @param accountNumber the account number
	 * @return the account details
	 */
	@GetMapping("/{accountNumber}") // http://localhost:8081/accounts/{accountNumber}
	public ResponseEntity<Optional<Account>> getAccountByNumber(@PathVariable String accountNumber) {
		Optional<Account> account = accountService.getAccountByNumber(accountNumber);
		if (account == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		return ResponseEntity.ok(account);
	}

	/**
	 * Deletes an account by ID.
	 * 
	 * @param id the ID of the account to be deleted
	 * @return a confirmation message
	 */
	@DeleteMapping("/remove/{id}") // http://localhost:8081/accounts/remove/{id}
	public ResponseEntity<String> deleteAccount(@PathVariable Long id) {
		accountService.deleteAccount(id);
		return new ResponseEntity<>("Account deleted successfully!", HttpStatus.OK);
	}

	/**
	 * Retrieves the balance of an account by account number.
	 *
	 * @param accountNumber the account number
	 * @return the account balance
	 */
	@GetMapping("/balance/{accountNumber}")
	public ResponseEntity<Double> getBalance(@PathVariable String accountNumber) {
		Double balance = accountService.getBalance(accountNumber);
		if (balance == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
 
        // Convert balance to a properly formatted value
        BigDecimal formattedBalance = BigDecimal.valueOf(balance).setScale(4, RoundingMode.HALF_UP);
 
        return ResponseEntity.ok(formattedBalance.doubleValue());
	}

	/**
	 * Adds balance to an account.
	 *
	 * @param accountNumber the account number
	 * @param amount        the amount to add
	 * @return a confirmation message
	 */
	@PutMapping("/addBalance/{accountNumber}/{amount}")
	public ResponseEntity<String> addBalance(@PathVariable String accountNumber, @PathVariable Double amount) {
		accountService.addBalance(accountNumber, amount);
		return ResponseEntity.ok("Balance updated successfully");
	}

	/**
	 * Deducts balance from an account.
	 *
	 * @param accountNumber the account number
	 * @param amount        the amount to deduct
	 * @return a confirmation message or error message if insufficient balance
	 */
	@PutMapping("/deductBalance/{accountNumber}/{amount}")
	public ResponseEntity<String> deductBalance(@PathVariable String accountNumber, @PathVariable Double amount) {
		boolean success = accountService.deductBalance(accountNumber, amount);
		if (!success) {
			return ResponseEntity.badRequest().body("Insufficient balance");
		}
		return ResponseEntity.ok("Balance deducted successfully");
	}
	

	  @PostMapping("/register")
	    public ResponseEntity<String> createAccount(@RequestBody Account accountDTO) {
	        accountService.createAccount(accountDTO);
	        return ResponseEntity.ok("Account Created Successfully");
	    }
	  
//	  @GetMapping("/{email}")
//	    public Account getByEmail(@RequestParam String email) {
//	        accountService.getAccountByEmail(email);
//	        return  accountService.getAccountByEmail(email);
//	    }
}
