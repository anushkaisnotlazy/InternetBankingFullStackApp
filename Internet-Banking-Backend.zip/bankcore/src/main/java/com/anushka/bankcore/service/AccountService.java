package com.anushka.bankcore.service;

import java.util.List;
import java.util.Optional;

import com.anushka.bankcore.model.Account;
public interface AccountService {
	Account createAccount(Account account);

	List<Account> getAllAccounts();

	Optional<Account> getAccountByNumber(String accountNumber);

	Account getAccountById(Long id);

	void deleteAccount(Long id);

//	Account save(Account account);

	Double getBalance(String accountNumber);

	void addBalance(String accountNumber, Double amount);

	boolean deductBalance(String accountNumber, Double amount);


	
	Account getAccountByEmail(String email);
}