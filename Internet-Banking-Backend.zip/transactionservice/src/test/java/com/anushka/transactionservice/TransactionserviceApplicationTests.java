package com.anushka.transactionservice;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.anushka.transactionservice.feign.BankCoreClient;
import com.anushka.transactionservice.model.Transaction;
import com.anushka.transactionservice.repository.TransactionRepository;
import com.anushka.transactionservice.service.TransactionServiceImpl;

@SpringBootTest
class TransactionserviceApplicationTests {

	@Mock
    private TransactionRepository transactionRepository;

    @Mock
    private BankCoreClient bankCoreClient;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    public void testGetTransactionHistory() {
        String accountNumber = "123456";
        List<Transaction> transactions = Arrays.asList(new Transaction(), new Transaction());

        when(transactionRepository.findByAccountNumber(accountNumber)).thenReturn(transactions);

        List<Transaction> result = transactionService.getTransactionHistory(accountNumber);

        verify(transactionRepository, times(1)).findByAccountNumber(accountNumber);
    }
       

}
