package com.anushka.transactionservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.anushka.transactionservice.dto.AccountDTO;
 
@FeignClient(name = "bankcore-service", url = "http://localhost:8081/accounts")
public interface BankCoreClient {
 
    /**
     * Calls the BankCore Service to add balance to an account.
     *
     * @param accountNumber the account number
     * @param amount the amount to add
     */
    @PutMapping("/addBalance/{accountNumber}/{amount}")
    void addBalance(@PathVariable("accountNumber") String accountNumber,
                    @PathVariable("amount") double amount);
 
    /**
     * Calls the BankCore Service to deduct balance from an account.
     *
     * @param accountNumber the account number
     * @param amount the amount to deduct
     */
    @PutMapping("/deductBalance/{accountNumber}/{amount}")
    void deductBalance(@PathVariable("accountNumber") String accountNumber,
                       @PathVariable("amount") double amount);
 
    /**
     * Retrieves the current balance of an account.
     *
     * @param accountNumber the account number
     * @return the balance as a Double
     */
    @GetMapping("/balance/{accountNumber}")
    Double getBalance(@PathVariable("accountNumber") String accountNumber);
 
    /**
     * Verifies if an account exists.
     *
     * @param accountNumber the account number
     * @return true if the account exists, false otherwise
     */
    @GetMapping("/verify/{accountNumber}")
    Boolean verifyAccount(@PathVariable("accountNumber") String accountNumber);
    
    
    @GetMapping("/accounts/{accountNumber}")
    AccountDTO getAccountByNumber(@PathVariable String accountNumber);
}
