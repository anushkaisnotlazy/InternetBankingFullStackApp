package com.anushka.userservice.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class AccountDTO {

	private Long userId;
	private String accountNumber;
	private String accountHolderName;
	private String accountHolderEmail;
	
	public String getAccountHolderEmail() {
		return accountHolderEmail;
	}
	public void setAccountHolderEmail(String accountHolderEmail) {
		this.accountHolderEmail = accountHolderEmail;
	}
	private double amount;
	public AccountDTO(Long userId, String accountNumber, double amount) {
		super();
		this.userId = userId;
		this.accountNumber = accountNumber;
		this.amount = amount;
	}
	public AccountDTO(Long id, String accountNumber, String name, double amount) {
		// TODO Auto-generated constructor stub
	}
	public AccountDTO() {
		// TODO Auto-generated constructor stub
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	
}