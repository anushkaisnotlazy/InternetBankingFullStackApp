package com.anushka.userservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.anushka.userservice.dto.UserDTO;
import com.anushka.userservice.feign.BankCoreClient;
import com.anushka.userservice.model.User;
import com.anushka.userservice.repository.UserRepository;
import com.anushka.userservice.service.UserServiceImpl;

@SpringBootTest
class UserserviceApplicationTests {

	@Mock
    private UserRepository userRepository;

    @Mock
    private BankCoreClient bankCoreClient;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void testRegisterUser() {
        UserDTO userDTO = new UserDTO("John Doe", "john.doe@example.com", "1234567890", 30);
        User user = new User();
        user.setId(1L);
        user.setName("John Doe");
        user.setEmail("john.doe@example.com");
        user.setMobileNumber("1234567890");
        user.setAge(30);
        user.setAccountNumber("123456789012");

        when(userRepository.save(any(User.class))).thenReturn(user);

        User savedUser = userService.registerUser(userDTO);

        assertNotNull(savedUser);
        assertEquals("John Doe", savedUser.getName());
        assertEquals("john.doe@example.com", savedUser.getEmail());
        verify(userRepository, times(1)).save(any(User.class));
    }


}
